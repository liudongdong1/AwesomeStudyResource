#include<iostream>
using namespace std;
int main(int argc,char* argv[])
  {
 	 unsigned short int x[4],y[4],r[11];
 	 unsigned short int a,b,c,d,e,f,g,h;
 	 cout<<"please input two 64-bit numbers:\n";
  	cout<<"N1:";
 	 cin>>a>>b>>c>>d;
 	 cout<<"N2:";
	  cin>>e>>f>>g>>h;
	  x[0]=a;
	  x[1]=b;
	  x[2]=c;
	  x[3]=d;
	  y[0]=e;
	  y[1]=f;
	  y[2]=g;
	  y[3]=h;
  
  for(int k=0;k<11;k++)
  {
 	 r[k]=0x0000;
  }
  for(int i=0;i<4;i++)
  {
  	for(int j=0;j<4;j++)
  	{
 		 a=r[10-i-j];
		 b=r[9-i-j];
 		c=r[8-i-j];
  		d=r[7-i-j];
  		e=r[6-i-j];
  		f=x[3-i];
		g=y[3-j];
		_asm
		{
			mov 		ax,f
			mul		g
			add		a,ax
			adc		b,dx
			adc		c,0
			adc		d,0
			adc		e,0
		}
		r[10-i-j]=a;
		r[9-i-j]=b;
		r[8-i-j]=c;
		r[7-i-j]=d;
		r[6-i-j]=e;
	}
}
	cout<<"There results:"<<x[0]<<x[1]<<x[2]<<x[3]<<"*"<<y[0]<<y[1]<<y[2]<<y[3]<<"="<<r[3]<<r[4]<<r[5]<<r[6]<<r[7]<<r[8]<<r[9]<<r[10]<<endl;
	system("pause");
	return 0;
}
