#include <stdio.h>
#include <stdlib.h>
int main()
{
	FILE *fp;
	char ch;
	int choose=1;
	printf("========================================\n");
	char *temp[3]={{"==   1��key input stream to file            ==\n"},
				{"==      2��show the message                   ==\n"},
				{"==      3. exit                               ==\n"}
	};
	int i=0
	for(;i<3;i++)
			printf("%s\n",temp[i]);
	printf("===================================== === \n");
	while(choose!=3)
	{
		printf("please input a choice:");
	    scanf("%d",&choose);
		printf("you choose %s\n",temp[choose-1]);
		if(choose==1)
		{
			if(fp=fopen("my.txt","a"))
			{
				while((ch=fgetc(stdout))!=EOF)
					fputc(ch,fp);
			}
			fclose(fp);

		}
		if(choose==2)
		{
			if(fp=fopen("my.txt","r"))
			{
				while((ch=fgetc(fp))!=EOF)
					fputc(ch,stdout);
			}
			fclose(fp);
		}
	}
	

}