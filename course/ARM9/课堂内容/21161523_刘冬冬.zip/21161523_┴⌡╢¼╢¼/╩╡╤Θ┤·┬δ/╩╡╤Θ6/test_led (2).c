#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
///#include <linux/delay.h>

#define TUBE_IOCTROL  0x11
#define DOT_IOCTROL   0x12
unsigned char data[10]={0xf0,0,0,0,0,0,0,0,0,0
	};
unsigned char dataliushui[9]={0x00,0x01,0x03,0x07,0x0f,0x1f,0x3f,0x7f,0xff};
unsigned char dataflash[2]={0x11,0x80};
void clear()
{
	int i=0;
	for(;i<10;i++){
		data[i]=0;
	}
}
void dealA(int i)
{

}
void jmdelay(int n) {
    int i,j,k;
    for (i=0;i<n;i++)
        for (j=0;j<100;j++)
            for (k=0;k<100;k++);
}

int main() {
    int fd;
    int i,j,k,choose,l,c;
    unsigned int LEDWORD;
    unsigned int MLEDA[8];
    unsigned char LEDCODE[10]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
    unsigned char dd_data[16][10]={{0xf0,0,0,0,0,0,0,0,0,0},
	{0,0xf0,0,0,0,0,0,0,0,0},
	{0,0,0xff,0,0,0,0,0,0,0},
	{0,0,0,0xff,0,0,0,0,0,0},
	{0,0,0,0,0xff,0,0,0,0,0},
	{0,0,0,0,0,0xff,0,0,0,0},
	{0,0,0,0,0,0,0xff,0,0,0},
	{0,0,0,0,0,0,0,0xff,0,0},
	{0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0,0},
	{0x2,0x2,0x2,0x2,0x2,0x2,0x2,0x2,0,0},
	{0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0,0},
	{0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0,0},
	{0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0,0},
	{0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0,0},
	{0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0,0},
	{0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0,0},
    };
	
    fd=open("/dev/s3c2440_led0",O_RDWR);
    if (fd < 0) {
        printf("####Led device open fail####\n");
        return (-1);
    }

    LEDWORD=0xff00;

    printf("will enter DIG LED  ,please waiting .............. \n");

    sleep(1);
    while(1){
	    char a;
		printf("please input the char\n");
	    scanf("%c",&a);
		printf("you input %c\n",a);
		clear();
		if(a=='a')
		{
			int t=0;
			int ch=0;
			for(;t<100;t++){
				ch=t%9;
				data[3]=dataliushui[ch];
				data[6]=dataliushui[9-ch];
				write(fd,data,1);
				jmdelay(500); 
			}
		}
		else{
			int t=0;
			int ch=0;
			for(;t<100;t++)
			{
				clear();
				ch=t%4;
				switch(ch){
				case 0:
					data[0]=0x11;
					break;
				case 1:
					data[0]=0x80;
					break;
				case 3:
					data[7]=0x11;
					break;
				case 4:
					data[7]=0x80;
					break;
				default:
					break;

				}
				write(fd,data,1);
				jmdelay(500); 
			}

		}
		     
    }
    close(fd);
    return 0;

}

